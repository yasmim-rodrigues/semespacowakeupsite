//define username
prompt("who is the user?")